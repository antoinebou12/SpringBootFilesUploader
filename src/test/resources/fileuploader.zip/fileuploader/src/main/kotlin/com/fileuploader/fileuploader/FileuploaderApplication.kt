package com.fileuploader.fileuploader

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class FileuploaderApplication

fun main(args: Array<String>) {
	runApplication<FileuploaderApplication>(*args)
}
